import { useState } from "react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  ResponsiveContainer,
} from "recharts";
import { Cpu, Gauge, Scale, Users, Coins, ChevronRight, ChevronLeft, RotateCcw } from "lucide-react";

const INK = "#14181F";
const PANEL = "#1C222C";
const PANEL_LIGHT = "#242C39";
const PARCHMENT = "#EDE8DC";
const MUTED = "#8B93A1";
const RULE = "#333B48";

const SERIF = "'Spectral', Georgia, serif";
const SANS = "'IBM Plex Sans', 'Segoe UI', sans-serif";

const DIMENSIONS = [
  {
    id: "taskFit",
    name: "Task Allocation Fit",
    color: "#6B84A3",
    icon: Cpu,
    prompt: "How you decide what AI handles versus what people handle",
    questions: [
      "We've mapped which tasks are better suited to AI versus human judgment, rather than applying AI uniformly across a workflow.",
      "Workers can override or adjust AI-recommended task allocations when their judgment says otherwise.",
      "We revisit the AI/human split as the tool's capabilities change, rather than treating it as fixed at rollout.",
    ],
  },
  {
    id: "trust",
    name: "Trust Calibration",
    color: "#4E9C96",
    icon: Gauge,
    prompt: "Whether reliance on the AI matches how good it actually is",
    questions: [
      "Workers' reliance on AI recommendations tracks how accurate the AI actually is on that type of task.",
      "We track cases where workers accept bad AI suggestions or reject good ones, not just overall usage rates.",
      "New workers are trained on where the AI is weak, not just on how to operate it.",
    ],
  },
  {
    id: "equity",
    name: "Distributive Equity",
    color: "#C1666B",
    icon: Scale,
    prompt: "Whether AI narrows or widens gaps between workers",
    questions: [
      "AI access has narrowed the performance gap between our newest and most experienced workers, not just raised the average.",
      "We measure how AI affects the spread of outcomes across workers, not only the average outcome.",
      "Workers who gain less from the AI tool are not penalized in reviews for smaller relative improvement.",
    ],
  },
  {
    id: "voice",
    name: "Procedural Voice",
    color: "#8A9A5B",
    icon: Users,
    prompt: "Whether employees shape how AI gets deployed",
    questions: [
      "Employees had a real channel to shape how this AI tool was piloted, not just a notice after the decision was made.",
      "There's a standing mechanism — a committee, forum, or works council — where employees can raise concerns about AI use.",
      "Employee feedback has visibly changed how the AI tool is deployed at least once.",
    ],
  },
  {
    id: "ownership",
    name: "Distributive Ownership",
    color: "#C9A227",
    icon: Coins,
    prompt: "Whether employees share the financial upside AI creates",
    questions: [
      "Employees have a direct financial stake — equity, profit-sharing, or gainsharing — in productivity gains AI helps produce.",
      "The organization has communicated, in concrete terms, how AI-driven gains flow back to employees.",
      "Employees would describe the financial upside from AI as shared, not captured solely by ownership or management.",
    ],
  },
];

const SCALE_LABELS = ["Strongly disagree", "Disagree", "Neutral", "Agree", "Strongly agree"];

function average(nums) {
  if (!nums.length) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function tier(score) {
  if (score >= 3.6) return "high";
  if (score >= 2.6) return "moderate";
  return "low";
}

function buildInsights(scores) {
  const insights = [];
  const t = Object.fromEntries(Object.entries(scores).map(([k, v]) => [k, tier(v)]));

  if (t.taskFit === "high" && t.trust === "low") {
    insights.push({
      color: "#4E9C96",
      text: "Task allocation looks deliberate, but reliance isn't tracking AI accuracy. This is the classic automation-complacency pattern — good design can still produce over- or under-reliance if calibration isn't monitored.",
    });
  }
  if (t.equity === "low") {
    insights.push({
      color: "#C1666B",
      text: "AI doesn't yet appear to be narrowing performance gaps. In the strongest field evidence (customer-service AI assistants), the biggest productivity gains went to novices, compressing the skill distribution. If your newest and most experienced workers are gaining equally — or your most experienced are gaining more — that's worth investigating rather than assuming it's fine.",
    });
  }
  if (t.voice === "low" && t.ownership === "low") {
    insights.push({
      color: "#C1666B",
      text: "Neither procedural voice nor financial upside is well established. This is the highest-risk combination for trust: employees experience AI as something done to them rather than with them, on both the decision-making and the payoff side.",
    });
  } else if (t.voice === "high" && t.ownership === "low") {
    insights.push({
      color: "#8A9A5B",
      text: "Employees have a real say but no financial stake in the outcome. Voice without shared upside can still produce fairness complaints once productivity gains become visible — people notice being consulted about a tool that primarily benefits someone else's bottom line.",
    });
  } else if (t.ownership === "high" && t.voice === "low") {
    insights.push({
      color: "#C9A227",
      text: "Employees have a financial stake but limited say in deployment decisions. Ownership alone doesn't guarantee trust — the ESOP literature suggests voice and ownership work together, not as substitutes.",
    });
  } else if (t.voice === "high" && t.ownership === "high") {
    insights.push({
      color: "#C9A227",
      text: "Both procedural voice and distributive ownership are strong. This is the combination associated with employee-owned firms showing structural advantages for AI adoption — worth treating as a strength to preserve as the AI tool's role grows.",
    });
  }
  if (t.taskFit === "low") {
    insights.push({
      color: "#6B84A3",
      text: "The AI/human task split doesn't yet look deliberate. Uniform application of AI regardless of task type is a common source of both wasted capability and worker frustration.",
    });
  }
  if (insights.length === 0) {
    insights.push({
      color: "#EDE8DC",
      text: "Scores are balanced across dimensions without a sharp weak point. The next step is usually to move from self-assessment to measurement — instrument at least one of these dimensions with real data rather than perception.",
    });
  }
  return insights;
}

export default function App() {
  const [step, setStep] = useState(0); // 0 = intro, 1..5 = dimensions, 6 = results
  const [answers, setAnswers] = useState({});

  const totalSteps = DIMENSIONS.length;
  const currentDim = step >= 1 && step <= totalSteps ? DIMENSIONS[step - 1] : null;

  const setAnswer = (qKey, value) => {
    setAnswers((prev) => ({ ...prev, [qKey]: value }));
  };

  const dimAnswered = (dim) =>
    dim.questions.every((_, qi) => answers[`${dim.id}-${qi}`] !== undefined);

  const canAdvance = currentDim ? dimAnswered(currentDim) : true;

  const scores = Object.fromEntries(
    DIMENSIONS.map((d) => [
      d.id,
      average(d.questions.map((_, qi) => answers[`${d.id}-${qi}`]).filter((v) => v !== undefined)),
    ])
  );
  const composite = average(Object.values(scores));

  const radarData = DIMENSIONS.map((d) => ({
    dimension: d.name.split(" ").slice(-1)[0],
    full: d.name,
    value: Number(scores[d.id].toFixed(2)),
  }));

  const reset = () => {
    setAnswers({});
    setStep(0);
  };

  return (
    <div
      style={{ background: INK, color: PARCHMENT, fontFamily: SANS, minHeight: "600px" }}
      className="w-full rounded-lg p-6 md:p-10"
    >
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
      `}</style>

      {/* Header */}
      <div className="flex items-baseline justify-between mb-8 pb-4" style={{ borderBottom: `1px solid ${RULE}` }}>
        <div>
          <h1 style={{ fontFamily: SERIF, fontSize: "1.6rem", fontWeight: 600, letterSpacing: "0.01em" }}>
            The AI–Human Ledger
          </h1>
          <p style={{ color: MUTED, fontSize: "0.85rem", marginTop: "2px" }}>
            A diagnostic for whether your AI mix is earning trust, not just output
          </p>
        </div>
        {step > 0 && (
          <div style={{ fontFamily: SERIF, color: MUTED, fontSize: "0.9rem" }}>
            {step <= totalSteps ? `${step} / ${totalSteps}` : "Ledger"}
          </div>
        )}
      </div>

      {/* Intro */}
      {step === 0 && (
        <div className="max-w-xl">
          <p style={{ fontSize: "0.95rem", lineHeight: 1.7, color: PARCHMENT }}>
            Five short sections, three statements each. Answer for one specific AI-assisted
            workflow in your organization — not "AI in general." At the end you'll get a
            balance sheet across task design, trust calibration, equity, voice, and ownership,
            with notes on where the imbalances usually cause trouble.
          </p>
          <div className="mt-6 space-y-2">
            {DIMENSIONS.map((d) => {
              const Icon = d.icon;
              return (
                <div key={d.id} className="flex items-center gap-3 py-2" style={{ borderBottom: `1px solid ${RULE}` }}>
                  <Icon size={16} color={d.color} strokeWidth={1.75} />
                  <span style={{ fontSize: "0.88rem" }}>{d.name}</span>
                  <span style={{ fontSize: "0.8rem", color: MUTED, marginLeft: "auto" }}>{d.prompt}</span>
                </div>
              );
            })}
          </div>
          <button
            onClick={() => setStep(1)}
            className="mt-8 px-5 py-2.5 rounded"
            style={{ background: "#C9A227", color: INK, fontWeight: 600, fontSize: "0.9rem" }}
          >
            Begin diagnostic
          </button>
        </div>
      )}

      {/* Dimension question pages */}
      {currentDim && (
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-1">
            <currentDim.icon size={18} color={currentDim.color} strokeWidth={1.75} />
            <h2 style={{ fontFamily: SERIF, fontSize: "1.25rem", fontWeight: 600 }}>{currentDim.name}</h2>
          </div>
          <p style={{ color: MUTED, fontSize: "0.85rem", marginBottom: "1.75rem" }}>{currentDim.prompt}</p>

          <div className="space-y-7">
            {currentDim.questions.map((q, qi) => {
              const key = `${currentDim.id}-${qi}`;
              const val = answers[key];
              return (
                <div key={key}>
                  <p style={{ fontSize: "0.92rem", lineHeight: 1.6, marginBottom: "0.75rem" }}>{q}</p>
                  <div className="flex items-center gap-3">
                    <span style={{ fontSize: "0.68rem", color: MUTED, width: "80px" }}>{SCALE_LABELS[0]}</span>
                    <div className="flex gap-3 flex-1 justify-center">
                      {[1, 2, 3, 4, 5].map((n) => (
                        <button
                          key={n}
                          onClick={() => setAnswer(key, n)}
                          aria-label={SCALE_LABELS[n - 1]}
                          style={{
                            width: 30,
                            height: 30,
                            borderRadius: "50%",
                            border: `1.5px solid ${val === n ? currentDim.color : RULE}`,
                            background: val === n ? currentDim.color : "transparent",
                            color: val === n ? INK : MUTED,
                            fontFamily: SERIF,
                            fontSize: "0.85rem",
                            cursor: "pointer",
                            transition: "all 0.15s ease",
                          }}
                        >
                          {n}
                        </button>
                      ))}
                    </div>
                    <span style={{ fontSize: "0.68rem", color: MUTED, width: "80px", textAlign: "right" }}>
                      {SCALE_LABELS[4]}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between mt-10">
            <button
              onClick={() => setStep((s) => s - 1)}
              className="flex items-center gap-1 px-4 py-2 rounded"
              style={{ color: MUTED, fontSize: "0.85rem" }}
            >
              <ChevronLeft size={15} /> Back
            </button>
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={!canAdvance}
              className="flex items-center gap-1 px-5 py-2 rounded"
              style={{
                background: canAdvance ? currentDim.color : PANEL_LIGHT,
                color: canAdvance ? INK : MUTED,
                fontWeight: 600,
                fontSize: "0.85rem",
                cursor: canAdvance ? "pointer" : "not-allowed",
              }}
            >
              {step === totalSteps ? "See ledger" : "Next"} <ChevronRight size={15} />
            </button>
          </div>
        </div>
      )}

      {/* Results */}
      {step === totalSteps + 1 && (
        <div>
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div>
              <div style={{ fontFamily: SERIF, fontSize: "0.85rem", color: MUTED, marginBottom: "0.25rem" }}>
                Composite balance
              </div>
              <div style={{ fontFamily: SERIF, fontSize: "3rem", fontWeight: 600, lineHeight: 1 }}>
                {composite.toFixed(2)}
                <span style={{ fontSize: "1.2rem", color: MUTED }}> / 5.00</span>
              </div>

              <div className="mt-6 space-y-4">
                {DIMENSIONS.map((d) => (
                  <div key={d.id}>
                    <div className="flex justify-between mb-1" style={{ fontSize: "0.82rem" }}>
                      <span>{d.name}</span>
                      <span style={{ fontFamily: SERIF, color: d.color }}>{scores[d.id].toFixed(2)}</span>
                    </div>
                    <div style={{ height: 5, background: PANEL_LIGHT, borderRadius: 2 }}>
                      <div
                        style={{
                          height: 5,
                          width: `${(scores[d.id] / 5) * 100}%`,
                          background: d.color,
                          borderRadius: 2,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ height: 300 }}>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} outerRadius="75%">
                  <PolarGrid stroke={RULE} />
                  <PolarAngleAxis dataKey="dimension" tick={{ fill: PARCHMENT, fontSize: 11 }} />
                  <Radar dataKey="value" stroke="#C9A227" fill="#C9A227" fillOpacity={0.25} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="mt-10 pt-6" style={{ borderTop: `1px solid ${RULE}` }}>
            <h3 style={{ fontFamily: SERIF, fontSize: "1.05rem", fontWeight: 600, marginBottom: "1rem" }}>
              Ledger notes
            </h3>
            <div className="space-y-4">
              {buildInsights(scores).map((ins, i) => (
                <div key={i} className="flex gap-3">
                  <div style={{ width: 3, background: ins.color, borderRadius: 2, flexShrink: 0 }} />
                  <p style={{ fontSize: "0.88rem", lineHeight: 1.65, color: PARCHMENT }}>{ins.text}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={reset}
            className="mt-8 flex items-center gap-2 px-4 py-2 rounded"
            style={{ color: MUTED, fontSize: "0.82rem", border: `1px solid ${RULE}` }}
          >
            <RotateCcw size={13} /> Run again for another workflow
          </button>
        </div>
      )}
    </div>
  );
}
