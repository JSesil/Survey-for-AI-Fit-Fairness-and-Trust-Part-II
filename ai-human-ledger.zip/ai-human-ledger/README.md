# The AI–Human Ledger

An interactive diagnostic tool for organizations assessing their AI/human task
mix across task allocation, trust calibration, equity, procedural voice, and
distributive ownership.

## Deploying this for free (GitHub + Vercel)

1. **Create a GitHub account** at github.com if you don't have one.
2. **Create a new repository** (e.g. `ai-human-ledger`), then upload this
   entire folder's contents to it. Easiest way with no command line:
   on the repo page, click "Add file" → "Upload files," drag everything in
   except `node_modules` and `dist` (they aren't included in this zip anyway).
3. **Create a free Vercel account** at vercel.com and sign in with your
   GitHub account.
4. Click "Add New Project," select the `ai-human-ledger` repo, and click
   **Deploy**. Vercel auto-detects this as a Vite project — no configuration
   needed.
5. In a minute or two you'll get a live URL like
   `ai-human-ledger.vercel.app`. Every time you push a change to GitHub,
   Vercel redeploys automatically.
6. To use your own domain (e.g. `ledger.yourdomain.com`), add it under the
   project's Settings → Domains in Vercel and follow the DNS instructions.

## Embedding it in Ghost, Squarespace, etc.

Once deployed, you can embed it in an article or page with an iframe:

```html
<iframe
  src="https://your-deployed-url.vercel.app"
  style="width:100%; height:800px; border:none;"
></iframe>
```

## Local development

```
npm install
npm run dev
```

## Editing

The entire tool lives in `src/App.jsx` — dimensions, questions, and
insight logic are all defined near the top of the file.
